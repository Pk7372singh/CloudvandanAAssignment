const arr1 = [100, 40, 200, 31];
const arr2 = [5, 3, 22, 19, 0];
arr1.sort((a, b) => b - a);
arr2.sort((a, b) => b - a);

console.log("arr1 sorted :", arr1);
console.log("arr2 sorted :", arr2);
